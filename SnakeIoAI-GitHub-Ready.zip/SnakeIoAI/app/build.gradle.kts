plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.snakeai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.snakeai"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    // Runtime has ZERO third-party dependencies (platform APIs only).
    testImplementation("junit:junit:4.13.2") // JVM unit tests only (EPL-2.0)
}
