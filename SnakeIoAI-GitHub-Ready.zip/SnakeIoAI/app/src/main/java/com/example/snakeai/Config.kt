package com.example.snakeai

import android.content.Context
import com.example.snakeai.ai.EngineConfig
import com.example.snakeai.vision.AnalyzerConfig

data class AppConfig(
    val captureIntervalMs: Long,
    val decisionIntervalMs: Long,
    val captureScale: Int,
    val gridCols: Int,
    val bgThreshold: Int,
    val fgCellFraction: Float,
    val headXFrac: Float,
    val headYFrac: Float,
    val smoothing: Float,
    val swipeRadiusPx: Int,
    val swipeDurationMs: Long,
    val holdMode: Boolean,
    val foodWeight: Float,
    val hazardWeight: Float,
    val dangerCells: Float,
    val rayRangeCells: Float,
    val staticWarnMs: Long,
    val staticRecoverMs: Long,
    val staticGiveUpMs: Long,
    val recoveryTap: Boolean,
    val recoveryTapX: Float,
    val recoveryTapY: Float,
    val maxRunMinutes: Int,
    val leaveGameTimeoutSec: Int,
    val debugOverlay: Boolean
) {
    fun analyzerConfig() = AnalyzerConfig(
        cols = gridCols, bgThreshold = bgThreshold, fgCellFraction = fgCellFraction,
        headXFrac = headXFrac, headYFrac = headYFrac
    )

    fun engineConfig() = EngineConfig(
        smoothing = smoothing, foodWeight = foodWeight, hazardWeight = hazardWeight,
        danger = dangerCells, rayRange = rayRangeCells
    )
}

object AppSettings {
    data class Def(val key: String, val label: String, val default: String)

    val defs = listOf(
        Def("captureIntervalMs", "Capture interval (ms)", "100"),
        Def("decisionIntervalMs", "Decision interval (ms)", "150"),
        Def("captureScale", "Capture downscale divisor (1-8)", "3"),
        Def("gridCols", "Analysis grid columns (16-120)", "48"),
        Def("bgThreshold", "Background colour tolerance (RGB distance)", "38"),
        Def("fgCellFraction", "Cell occupied fraction (0-1)", "0.22"),
        Def("headXFrac", "Player head X (fraction of screen width)", "0.5"),
        Def("headYFrac", "Player head Y (fraction of screen height)", "0.5"),
        Def("smoothing", "Direction smoothing (0-0.9)", "0.4"),
        Def("swipeRadiusPx", "Steering radius (px)", "220"),
        Def("swipeDurationMs", "Gesture duration (ms)", "130"),
        Def("holdMode", "Hold-touch mode (0 = swipes, 1 = experimental)", "0"),
        Def("foodWeight", "Food attraction weight", "2.0"),
        Def("hazardWeight", "Hazard avoidance weight", "8.0"),
        Def("dangerCells", "Danger distance (grid cells)", "5"),
        Def("rayRangeCells", "Look-ahead range (grid cells)", "14"),
        Def("staticWarnMs", "Stuck: warn after (ms)", "3000"),
        Def("staticRecoverMs", "Stuck: recovery after (ms)", "8000"),
        Def("staticGiveUpMs", "Stuck: auto-stop after (ms)", "60000"),
        Def("recoveryTap", "Recovery tap on stuck (0/1, can hit ads!)", "0"),
        Def("recoveryTapX", "Recovery tap X (fraction)", "0.5"),
        Def("recoveryTapY", "Recovery tap Y (fraction)", "0.8"),
        Def("maxRunMinutes", "Auto-stop after (minutes, 0 = off)", "15"),
        Def("leaveGameTimeoutSec", "Auto-stop if game not in foreground (s)", "20"),
        Def("debugOverlay", "Debug minimap overlay (0/1)", "0")
    )

    private const val PREFS = "snakeai"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun get(ctx: Context, key: String): String =
        prefs(ctx).getString(key, null) ?: defs.first { it.key == key }.default

    fun put(ctx: Context, key: String, value: String) {
        prefs(ctx).edit().putString(key, value).apply()
    }

    fun targetPackage(ctx: Context): String = prefs(ctx).getString("targetPackage", "") ?: ""

    fun setTargetPackage(ctx: Context, pkg: String) {
        prefs(ctx).edit().putString("targetPackage", pkg.trim()).apply()
    }

    fun load(ctx: Context): AppConfig {
        fun f(k: String): Float = get(ctx, k).toFloatOrNull() ?: defs.first { it.key == k }.default.toFloat()
        fun l(k: String): Long = f(k).toLong()
        fun i(k: String): Int = f(k).toInt()
        fun b(k: String): Boolean = f(k) >= 0.5f
        return AppConfig(
            captureIntervalMs = l("captureIntervalMs").coerceAtLeast(30L),
            decisionIntervalMs = l("decisionIntervalMs").coerceAtLeast(50L),
            captureScale = i("captureScale").coerceIn(1, 8),
            gridCols = i("gridCols").coerceIn(16, 120),
            bgThreshold = i("bgThreshold").coerceIn(5, 200),
            fgCellFraction = f("fgCellFraction").coerceIn(0.02f, 1f),
            headXFrac = f("headXFrac").coerceIn(0f, 1f),
            headYFrac = f("headYFrac").coerceIn(0f, 1f),
            smoothing = f("smoothing").coerceIn(0f, 0.9f),
            swipeRadiusPx = i("swipeRadiusPx").coerceIn(40, 1000),
            swipeDurationMs = l("swipeDurationMs").coerceIn(30L, 1000L),
            holdMode = b("holdMode"),
            foodWeight = f("foodWeight"),
            hazardWeight = f("hazardWeight"),
            dangerCells = f("dangerCells").coerceIn(1f, 20f),
            rayRangeCells = f("rayRangeCells").coerceIn(4f, 40f),
            staticWarnMs = l("staticWarnMs"),
            staticRecoverMs = l("staticRecoverMs"),
            staticGiveUpMs = l("staticGiveUpMs"),
            recoveryTap = b("recoveryTap"),
            recoveryTapX = f("recoveryTapX").coerceIn(0f, 1f),
            recoveryTapY = f("recoveryTapY").coerceIn(0f, 1f),
            maxRunMinutes = i("maxRunMinutes").coerceAtLeast(0),
            leaveGameTimeoutSec = i("leaveGameTimeoutSec").coerceAtLeast(3),
            debugOverlay = b("debugOverlay")
        )
    }
}
