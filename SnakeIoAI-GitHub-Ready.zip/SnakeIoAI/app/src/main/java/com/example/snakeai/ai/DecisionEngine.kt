package com.example.snakeai.ai

import com.example.snakeai.vision.Analysis
import com.example.snakeai.vision.CellKind
import com.example.snakeai.vision.Food
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.sin

val PIF: Float = PI.toFloat()
val TWO_PI: Float = (2 * PI).toFloat()

/** Smallest signed difference a-b in (-PI, PI]. */
fun angDiff(a: Float, b: Float): Float {
    var d = a - b
    while (d > PIF) d -= TWO_PI
    while (d < -PIF) d += TWO_PI
    return d
}

enum class Mode { FOOD, EXPLORE, AVOID, BREAKOUT, NO_SNAKE }

data class EngineConfig(
    val candidates: Int = 36,
    val rayRange: Float = 14f,      // look-ahead in grid cells
    val danger: Float = 5f,         // clearance below which a direction is penalised
    val foodWeight: Float = 2f,
    val hazardWeight: Float = 8f,
    val freeWeight: Float = 1f,
    val turnWeight: Float = 0.8f,
    val maxTurn: Float = 2.4f,      // rad; do not plan U-turns
    val smoothing: Float = 0.4f,    // 0 = no smoothing, 0.9 = very sluggish
    val foodRange: Float = 24f,
    val ownIgnoreCells: Float = 3f, // own body this close to the head is not a collision
    val circleTurnSum: Float = 10f, // accumulated signed turning (rad) that counts as circling
    val circleWindow: Int = 40,
    val breakoutSteps: Int = 10
)

data class Decision(
    val angle: Float,        // radians, screen coordinates (0 = right, +PI/2 = down)
    val mode: Mode,
    val clearance: Float,    // free distance (cells) along the chosen direction
    val target: Food?,
    val headingUsed: Float,
    val steer: Boolean,
    val note: String = ""
)

class DecisionEngine(private val cfg: EngineConfig = EngineConfig()) {
    private var lastAngle: Float? = null
    private var smx = 0f
    private var smy = 0f
    private var hasSmooth = false
    private val turns = ArrayDeque<Float>()
    private var turnSum = 0f
    private var step = 0
    private var straightUntil = 0

    fun reset() {
        lastAngle = null; hasSmooth = false; turns.clear(); turnSum = 0f; step = 0; straightUntil = 0
    }

    fun decide(a: Analysis): Decision {
        step++
        if (!a.hasSnake) {
            return Decision(lastAngle ?: 0f, Mode.NO_SNAKE, 0f, null, lastAngle ?: 0f, false, "no snake at head position")
        }
        val heading = estimateHeading(a)
        val n = cfg.candidates
        val angles = FloatArray(n) { -PIF + it * TWO_PI / n }
        val raw = FloatArray(n) { ray(a, angles[it]) }
        // Snake has width: a direction is only as clear as its worst neighbour.
        val clear = FloatArray(n) { minOf(raw[(it + n - 1) % n], raw[it], raw[(it + 1) % n]) }

        val breakout = step < straightUntil
        val target = if (breakout) null else pickFood(a, heading)
        val foodAngle = if (target != null) atan2(target.y - a.headY, target.x - a.headX) else 0f

        var best = -1
        var bestScore = -1e9f
        for (i in 0 until n) {
            val dTurn = abs(angDiff(angles[i], heading))
            if (dTurn > cfg.maxTurn) continue
            var s = cfg.freeWeight * (clear[i] / cfg.rayRange)
            if (clear[i] < cfg.danger) s -= cfg.hazardWeight * (1f - clear[i] / cfg.danger)
            if (target != null) {
                val d = angDiff(angles[i], foodAngle) / 0.35f
                s += cfg.foodWeight * exp(-d * d)
            }
            s -= (if (breakout) 3f else 1f) * cfg.turnWeight * dTurn / PIF
            if (s > bestScore) { bestScore = s; best = i }
        }
        if (best < 0) best = clear.indices.maxByOrNull { clear[it] } ?: 0

        var ang = angles[best]
        val emergency = raw[best] < cfg.danger * 0.6f
        if (!emergency && hasSmooth) {
            val k = cfg.smoothing
            ang = atan2(k * smy + (1f - k) * sin(ang), k * smx + (1f - k) * cos(ang))
        }
        smx = cos(ang); smy = sin(ang); hasSmooth = true

        val aheadClear = ray(a, heading)
        val mode = when {
            breakout -> Mode.BREAKOUT
            aheadClear < cfg.danger -> Mode.AVOID
            target != null -> Mode.FOOD
            else -> Mode.EXPLORE
        }

        // Circling detection: accumulated signed turning over a window.
        val prev = lastAngle
        if (prev != null) {
            val dl = angDiff(ang, prev)
            turns.addLast(dl); turnSum += dl
            if (turns.size > cfg.circleWindow) turnSum -= turns.removeFirst()
            if (abs(turnSum) > cfg.circleTurnSum && !breakout) {
                straightUntil = step + cfg.breakoutSteps
                turns.clear(); turnSum = 0f
            }
        }
        lastAngle = ang

        return Decision(ang, mode, ray(a, ang), target, heading, true,
            if (emergency) "emergency (no smoothing)" else "")
    }

    private fun estimateHeading(a: Analysis): Float {
        val bh = a.bodyHeading
        if (bh != null && a.headingConfidence >= 0.35f) return bh
        return lastAngle ?: (-PIF / 2f)
    }

    private fun pickFood(a: Analysis, heading: Float): Food? {
        var bestV = 0f
        var bestF: Food? = null
        for (f in a.foods) {
            val dx = f.x - a.headX
            val dy = f.y - a.headY
            val dist = hypot(dx, dy)
            if (dist < 1.2f || dist > cfg.foodRange) continue
            val fa = atan2(dy, dx)
            val dh = abs(angDiff(fa, heading))
            if (dh > cfg.maxTurn) continue
            if (ray(a, fa) < dist - 0.5f && dist <= cfg.rayRange) continue // blocked by a hazard
            val v = 1f / (dist + 2f) * (1f - 0.4f * dh / PIF)
            if (v > bestV) { bestV = v; bestF = f }
        }
        return bestF
    }

    /** Free distance (cells) from the head along [ang] before a hazard or own body is hit. */
    private fun ray(a: Analysis, ang: Float): Float {
        val dx = cos(ang)
        val dy = sin(ang)
        var d = 1.2f
        while (d <= cfg.rayRange) {
            val c = floor(a.headX + dx * d).toInt()
            val r = floor(a.headY + dy * d).toInt()
            when (a.kindAt(c, r)) {
                CellKind.OUTSIDE -> return cfg.rayRange   // unknown beyond the view: assume free
                CellKind.HAZARD -> return d
                CellKind.OWN -> if (d > cfg.ownIgnoreCells) return d
                else -> {}
            }
            d += 0.5f
        }
        return cfg.rayRange
    }
}
