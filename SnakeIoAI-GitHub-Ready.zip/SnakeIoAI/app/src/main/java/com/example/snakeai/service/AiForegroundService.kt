package com.example.snakeai.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import com.example.snakeai.AppConfig
import com.example.snakeai.AppSettings
import com.example.snakeai.AppState
import com.example.snakeai.ai.Decision
import com.example.snakeai.ai.DecisionEngine
import com.example.snakeai.ai.StuckDetector
import com.example.snakeai.capture.FrameConverter
import com.example.snakeai.control.TouchAccessibilityService
import com.example.snakeai.util.ScreenUtil
import com.example.snakeai.vision.Analysis
import com.example.snakeai.vision.FrameAnalyzer
import com.example.snakeai.vision.FracRect
import com.example.snakeai.vision.Zones
import kotlin.math.roundToInt

/**
 * Foreground service (type mediaProjection) that owns the capture + decision loops.
 *   capture loop : every captureIntervalMs  -> latest frame -> FrameAnalyzer -> latest Analysis
 *   decision loop: every decisionIntervalMs -> DecisionEngine -> gesture via accessibility service
 */
class AiForegroundService : Service() {
    companion object {
        const val ACTION_START = "com.example.snakeai.START"
        const val ACTION_STOP = "com.example.snakeai.STOP"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "snakeai_run"
        private const val NOTIF_ID = 42
    }

    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var projection: MediaProjection? = null
    private var projCallback: MediaProjection.Callback? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null

    private lateinit var cfg: AppConfig
    private lateinit var analyzer: FrameAnalyzer
    private lateinit var engine: DecisionEngine
    private lateinit var stuck: StuckDetector
    private var ignoreRects: List<FracRect> = emptyList()
    private var target = ""

    @Volatile private var running = false
    private var screenW = 0
    private var screenH = 0
    private var capW = 0
    private var capH = 0
    private var pixels = IntArray(0)
    @Volatile private var latest: Analysis? = null
    @Volatile private var lastFrameMs = 0L
    @Volatile private var lastDecision: Decision? = null
    private var startMs = 0L
    private var lastTargetSeenMs = 0L
    private var lastRecoveryMs = 0L
    private var lastUiMs = 0L
    private var frames = 0
    private var framesAtLastUi = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopAi("Stopped from notification")
            ACTION_START -> startAi(intent)
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopAi("Service destroyed")
        super.onDestroy()
    }

    // ------------------------------------------------------------------ start / stop

    private fun startAi(intent: Intent) {
        if (running) return
        createChannel()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
        try {
            setup(intent)
        } catch (e: Exception) {
            stopAi("Start failed: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    @Suppress("DEPRECATION")
    private fun readData(intent: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else intent.getParcelableExtra(EXTRA_DATA)

    private fun setup(intent: Intent) {
        val a11y = TouchAccessibilityService.instance
            ?: throw IllegalStateException("Accessibility service is not enabled")
        val data = readData(intent) ?: throw IllegalStateException("Missing screen-capture consent data")
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)

        cfg = AppSettings.load(this)
        target = AppSettings.targetPackage(this)
        if (target.isEmpty()) throw IllegalStateException("No target package set")

        val size = ScreenUtil.realSize(this)
        screenW = size.first
        screenH = size.second
        capW = (screenW / cfg.captureScale).coerceAtLeast(64)
        capH = (screenH / cfg.captureScale).coerceAtLeast(64)
        pixels = IntArray(capW * capH)
        analyzer = FrameAnalyzer(cfg.analyzerConfig())
        engine = DecisionEngine(cfg.engineConfig())
        stuck = StuckDetector(cfg.staticWarnMs, cfg.staticRecoverMs, cfg.staticGiveUpMs)
        ignoreRects = if (cfg.debugOverlay) listOf(Zones.STOP, Zones.MINIMAP) else listOf(Zones.STOP)

        val t = HandlerThread("snakeai-loop").also { it.start() }
        thread = t
        val h = Handler(t.looper)
        handler = h

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(resultCode, data)
        projection = proj
        val cb = object : MediaProjection.Callback() {
            override fun onStop() {
                h.post { stopAi("Screen capture was stopped by the system or user") }
            }
        }
        projCallback = cb
        proj.registerCallback(cb, h) // required before createVirtualDisplay on Android 14+

        val rd = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        reader = rd
        display = proj.createVirtualDisplay(
            "snakeai", capW, capH, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, h
        )

        val now = SystemClock.uptimeMillis()
        startMs = now
        lastTargetSeenMs = now
        stuck.reset(now)
        running = true
        AppState.running = true
        AppState.stopHook = Runnable { stopAi("Emergency STOP") }
        a11y.showOverlays(cfg.debugOverlay) { AppState.emergencyStop() }
        publish("Running – waiting for $target", "-", "capture ${capW}x$capH")
        h.post(captureLoop)
        h.post(decisionLoop)
    }

    @Synchronized
    private fun stopAi(reason: String) {
        val wasActive = running || projection != null || thread != null
        running = false
        handler?.removeCallbacksAndMessages(null)
        try {
            TouchAccessibilityService.instance?.let { it.gestures.release(); it.hideOverlays() }
        } catch (_: Exception) {}
        try { display?.release() } catch (_: Exception) {}
        display = null
        try { reader?.close() } catch (_: Exception) {}
        reader = null
        try {
            projCallback?.let { projection?.unregisterCallback(it) }
            projection?.stop()
        } catch (_: Exception) {}
        projection = null
        projCallback = null
        thread?.quitSafely()
        thread = null
        handler = null
        AppState.stopHook = null
        AppState.running = false
        if (wasActive) {
            AppState.status = "Stopped: $reason"
            AppState.notifyChanged()
        }
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        stopSelf()
    }

    // ------------------------------------------------------------------ loops

    private val captureLoop = object : Runnable {
        override fun run() {
            if (!running) return
            val t0 = SystemClock.uptimeMillis()
            try {
                captureOnce(t0)
            } catch (e: Exception) {
                stopAi("Capture error: ${e.javaClass.simpleName}: ${e.message}")
                return
            }
            if (!running) return
            val dt = SystemClock.uptimeMillis() - t0
            handler?.postDelayed(this, maxOf(1L, cfg.captureIntervalMs - dt))
        }
    }

    private val decisionLoop = object : Runnable {
        override fun run() {
            if (!running) return
            val t0 = SystemClock.uptimeMillis()
            try {
                decideOnce(t0)
            } catch (e: Exception) {
                stopAi("Decision error: ${e.javaClass.simpleName}: ${e.message}")
                return
            }
            if (!running) return
            val dt = SystemClock.uptimeMillis() - t0
            handler?.postDelayed(this, maxOf(1L, cfg.decisionIntervalMs - dt))
        }
    }

    private fun captureOnce(now: Long) {
        val img = reader?.acquireLatestImage() ?: return // null: screen unchanged, keep last analysis
        try {
            if (img.width != capW || img.height != capH) {
                stopAi("Display size changed (rotation?) – restart the AI")
                return
            }
            FrameConverter.toRgb(img, pixels)
        } finally {
            img.close()
        }
        val a = analyzer.analyze(pixels, capW, capH, ignoreRects)
        latest = a
        lastFrameMs = now
        frames++
        stuck.onFrame(pixels, capW, capH, now)
        stuck.noteSnake(a.hasSnake, now)
        TouchAccessibilityService.instance?.updateDebug(a, lastDecision)
    }

    private fun decideOnce(now: Long) {
        val a11y = TouchAccessibilityService.instance
        if (a11y == null) { stopAi("Accessibility service disconnected"); return }

        if (cfg.maxRunMinutes > 0 && now - startMs > cfg.maxRunMinutes * 60_000L) {
            stopAi("Max run time (${cfg.maxRunMinutes} min) reached"); return
        }

        val fg = a11y.activePackage()
        if (fg != target) {
            a11y.gestures.release()
            if (now - lastTargetSeenMs > cfg.leaveGameTimeoutSec * 1000L) {
                stopAi("Game not in foreground for ${cfg.leaveGameTimeoutSec}s"); return
            }
            publish("Paused – foreground is ${fg ?: "unknown"}, waiting for $target", "-", dbg(null))
            return
        }
        lastTargetSeenMs = now

        val a = latest
        if (a == null) { publish("Waiting for first frame", "-", dbg(null)); return }
        if (now - lastFrameMs > 1500) { publish("No new frames (static screen?)", "-", dbg(a)); }

        when (stuck.state(now)) {
            StuckDetector.State.GIVE_UP -> {
                stopAi("Nothing changed / no snake for ${stuck.stuckMs(now) / 1000}s – giving up"); return
            }
            StuckDetector.State.RECOVER -> {
                if (cfg.recoveryTap && now - lastRecoveryMs > 5000) {
                    lastRecoveryMs = now
                    a11y.gestures.tap(screenW * cfg.recoveryTapX, screenH * cfg.recoveryTapY)
                }
            }
            else -> {}
        }

        val d = engine.decide(a)
        lastDecision = d
        if (d.steer) {
            a11y.gestures.steer(
                screenW * cfg.headXFrac, screenH * cfg.headYFrac,
                d.angle, cfg.swipeRadiusPx.toFloat(), cfg.swipeDurationMs, cfg.holdMode
            )
        }
        val st = stuck.state(now)
        val status = when {
            d.mode.name == "NO_SNAKE" -> "No snake found at head position (menu / dead / ad?)"
            st != StuckDetector.State.OK -> "Running – possible stall: $st"
            else -> "Running"
        }
        val deg = (d.angle * 180f / Math.PI.toFloat()).roundToInt()
        publish(
            status,
            "${d.mode} angle=${deg}° clear=${"%.1f".format(d.clearance)} ${d.note}",
            dbg(a)
        )
    }

    private fun dbg(a: Analysis?): String {
        if (a == null) return "no analysis"
        val bh = a.bodyHeading?.let { (it * 180f / Math.PI.toFloat()).roundToInt().toString() + "°" } ?: "n/a"
        return "bg=${a.bgColors} own=${a.ownCells} haz=${a.hazardCells} food=${a.foods.size} " +
            "fg=${(a.fgFraction * 100).roundToInt()}% heading=$bh conf=${"%.2f".format(a.headingConfidence)}"
    }

    private fun publish(status: String, decision: String, debug: String) {
        val now = SystemClock.uptimeMillis()
        AppState.status = status
        AppState.decisionLine = decision
        if (now - lastUiMs >= 250) {
            val fps = (frames - framesAtLastUi) * 1000f / (now - lastUiMs).coerceAtLeast(1)
            framesAtLastUi = frames
            lastUiMs = now
            AppState.debugLine = "$debug fps=${"%.1f".format(fps)}"
            AppState.notifyChanged()
        }
    }

    // ------------------------------------------------------------------ notification

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Snake.io AI", NotificationManager.IMPORTANCE_LOW))
    }

    private fun buildNotification(): Notification {
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, AiForegroundService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_delete), "STOP", stopPi
        ).build()
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Snake.io AI is running")
            .setContentText("Capturing the screen and steering. Tap STOP to end.")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .addAction(action)
            .build()
    }
}
