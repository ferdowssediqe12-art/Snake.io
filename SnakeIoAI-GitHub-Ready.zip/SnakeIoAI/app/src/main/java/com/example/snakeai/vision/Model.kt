package com.example.snakeai.vision

/** Per-cell classification stored in [Analysis.kind]. */
object CellKind {
    const val OUTSIDE: Byte = -1
    const val BG: Byte = 0
    const val HAZARD: Byte = 1   // other snakes / large foreign blobs
    const val OWN: Byte = 2      // own snake (matched by head colour)
    const val FOOD: Byte = 3     // small / thin foreign items
    const val IGNORED: Byte = 4  // covered by our own overlay (STOP button, debug minimap)
}

/** Rectangle in fractions (0..1) of the frame. Plain Kotlin so it works in JVM unit tests. */
data class FracRect(val l: Float, val t: Float, val r: Float, val b: Float)

/** Fixed overlay zones. The analyser ignores them so our own UI is never mistaken for game objects. */
object Zones {
    val STOP = FracRect(0.30f, 0.06f, 0.70f, 0.12f)
    val MINIMAP = FracRect(0.02f, 0.70f, 0.30f, 0.98f)
}

/** Food position in grid-cell units (cell i spans [i, i+1)). */
data class Food(val x: Float, val y: Float)

data class AnalyzerConfig(
    val cols: Int = 48,
    val bgThreshold: Int = 38,          // RGB euclidean distance treated as "background"
    val fgCellFraction: Float = 0.22f,  // fraction of non-bg pixels for a cell to count as occupied
    val headXFrac: Float = 0.5f,        // where the player's head sits on screen
    val headYFrac: Float = 0.5f,
    val headSearchCells: Float = 3f,
    val useOwnColorSplit: Boolean = true,
    val ownColorThreshold: Int = 70,
    val minCoreCells: Int = 2,          // "thickness" test: snakes have interior cells, pellets don't
    val bodyMinCells: Int = 4,
    val bodyRadiusCells: Float = 9f,
    val maxFoods: Int = 150
)

class Analysis(
    val frameW: Int,
    val frameH: Int,
    val cols: Int,
    val rows: Int,
    val cellSize: Float,
    val kind: ByteArray,
    val foods: List<Food>,
    val headX: Float,
    val headY: Float,
    val bodyHeading: Float?,
    val headingConfidence: Float,
    val ownColor: Int?,
    val ownCells: Int,
    val hazardCells: Int,
    val fgFraction: Float,
    val bgColors: Int
) {
    val hasSnake: Boolean get() = ownCells >= 3

    fun kindAt(c: Int, r: Int): Byte =
        if (c in 0 until cols && r in 0 until rows) kind[r * cols + c] else CellKind.OUTSIDE
}
