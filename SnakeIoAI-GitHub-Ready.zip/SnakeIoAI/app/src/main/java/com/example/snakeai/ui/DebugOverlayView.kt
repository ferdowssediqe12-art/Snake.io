package com.example.snakeai.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import com.example.snakeai.ai.Decision
import com.example.snakeai.vision.Analysis
import com.example.snakeai.vision.CellKind
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Small non-touchable minimap of what the vision "sees". Drawn inside Zones.MINIMAP (ignored by analysis). */
class DebugOverlayView(ctx: Context) : View(ctx) {
    @Volatile private var analysis: Analysis? = null
    @Volatile private var decision: Decision? = null
    private val p = Paint()

    fun update(a: Analysis?, d: Decision?) {
        analysis = a; decision = d; postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val a = analysis ?: return
        p.style = Paint.Style.FILL
        p.color = 0xCC000000.toInt()
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), p)
        val s = min(width.toFloat() / a.cols, height.toFloat() / a.rows)
        for (r in 0 until a.rows) for (c in 0 until a.cols) {
            val k = a.kind[r * a.cols + c]
            if (k == CellKind.BG) continue
            p.color = when (k) {
                CellKind.HAZARD -> 0xFFFF3030.toInt()
                CellKind.OWN -> 0xFF30FF60.toInt()
                CellKind.FOOD -> 0xFFFFE030.toInt()
                else -> 0x66888888
            }
            canvas.drawRect(c * s, r * s, (c + 1) * s, (r + 1) * s, p)
        }
        val hx = a.headX * s
        val hy = a.headY * s
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.color = 0xFFFFFFFF.toInt()
        canvas.drawCircle(hx, hy, 2.5f * s, p)
        val bh = a.bodyHeading
        if (bh != null) {
            p.color = 0xFF30D0FF.toInt()
            canvas.drawLine(hx, hy, hx + cos(bh) * 7 * s, hy + sin(bh) * 7 * s, p)
        }
        val d = decision
        if (d != null && d.steer) {
            p.color = 0xFFFFFFFF.toInt()
            p.strokeWidth = 3f
            canvas.drawLine(hx, hy, hx + cos(d.angle) * 9 * s, hy + sin(d.angle) * 9 * s, p)
        }
    }
}
