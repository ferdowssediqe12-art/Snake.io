package com.example.snakeai.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.example.snakeai.util.ScreenUtil
import kotlin.math.cos
import kotlin.math.sin

/**
 * Sends steering gestures through AccessibilityService.dispatchGesture().
 *
 * SWIPE mode (default): every decision is a short drag from the head position towards
 *   head + direction * radius. The game is assumed to keep its last heading after the finger lifts.
 * HOLD mode (experimental): one continuous touch that is steered with continued strokes.
 */
class GestureController(private val svc: AccessibilityService) {
    @Volatile private var busyUntil = 0L
    private var held: GestureDescription.StrokeDescription? = null
    private var heldX = 0f
    private var heldY = 0f
    private val main = Handler(Looper.getMainLooper())
    private val screen = ScreenUtil.realSize(svc)

    private fun cx(v: Float) = v.coerceIn(2f, (screen.first - 2).toFloat())
    private fun cy(v: Float) = v.coerceIn(2f, (screen.second - 2).toFloat())

    /** Returns false when skipped (previous gesture still running) or rejected by the system. */
    fun steer(x: Float, y: Float, angle: Float, radius: Float, durMs: Long, hold: Boolean): Boolean {
        val now = SystemClock.uptimeMillis()
        if (now < busyUntil) return false
        val sx = cx(x)
        val sy = cy(y)
        val tx = cx(x + cos(angle) * radius)
        val ty = cy(y + sin(angle) * radius)
        val path = Path()
        val stroke: GestureDescription.StrokeDescription
        val prev = held
        if (hold && prev != null) {
            path.moveTo(heldX, heldY); path.lineTo(tx, ty)
            stroke = try { prev.continueStroke(path, 0, durMs, true) } catch (e: Exception) {
                held = null
                return false
            }
        } else {
            path.moveTo(sx, sy); path.lineTo(tx, ty)
            stroke = GestureDescription.StrokeDescription(path, 0, durMs, hold)
        }
        busyUntil = now + durMs + 400
        val ok = svc.dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    busyUntil = 0
                    if (hold) { held = stroke; heldX = tx; heldY = ty }
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    busyUntil = 0
                    held = null
                }
            }, main
        )
        if (!ok) { busyUntil = 0; held = null }
        return ok
    }

    fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(cx(x), cy(y)) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
        svc.dispatchGesture(g, null, null)
    }

    /** Lifts a held finger (HOLD mode). Safe to call at any time. */
    fun release() {
        val prev = held ?: return
        held = null
        try {
            val path = Path().apply { moveTo(heldX, heldY); lineTo(cx(heldX + 1f), heldY) }
            val s = prev.continueStroke(path, 0, 10, false)
            svc.dispatchGesture(GestureDescription.Builder().addStroke(s).build(), null, null)
        } catch (_: Exception) {
        }
    }
}
