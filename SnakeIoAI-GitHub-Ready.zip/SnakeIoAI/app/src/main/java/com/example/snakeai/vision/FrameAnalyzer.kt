package com.example.snakeai.vision

import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Colour-agnostic, dependency-free vision. Pure Kotlin on an IntArray of 0xRRGGBB pixels.
 *
 * Pipeline:
 *  1. Estimate 1-2 dominant background colours (histogram).
 *  2. Mark pixels that differ from the background; count them per grid cell.
 *  3. Own snake = the colour found around the screen position of the player's head
 *     (Snake.io keeps the camera on the player's head).
 *  4. Everything else that is occupied: thick blobs -> HAZARD (other snakes),
 *     thin/small blobs -> FOOD.
 *  5. Estimate heading from where the own body lies relative to the head.
 *
 * This is a heuristic. See README "Detection limitations".
 */
class FrameAnalyzer(private val cfg: AnalyzerConfig = AnalyzerConfig()) {

    fun analyze(px: IntArray, w: Int, h: Int, ignore: List<FracRect> = emptyList()): Analysis {
        val cols = cfg.cols
        val cell = w.toFloat() / cols
        val rows = max(1, (h / cell).toInt())
        val n = cols * rows
        val thr2 = cfg.bgThreshold * cfg.bgThreshold
        val bgs = estimateBackground(px, w, h, thr2)

        val ignored = BooleanArray(n)
        for (rect in ignore) {
            for (r in 0 until rows) for (c in 0 until cols) {
                val fx = (c + 0.5f) * cell / w
                val fy = (r + 0.5f) * cell / h
                if (fx >= rect.l && fx <= rect.r && fy >= rect.t && fy <= rect.b) ignored[r * cols + c] = true
            }
        }

        val hxPx = w * cfg.headXFrac
        val hyPx = h * cfg.headYFrac
        val headX = hxPx / cell
        val headY = hyPx / cell

        // Dominant non-background colour next to the head = own snake colour.
        var ownColor: Int? = null
        if (cfg.useOwnColorSplit) {
            val rad = (cell * cfg.headSearchCells).toInt().coerceAtLeast(4)
            val x0 = max(0, hxPx.toInt() - rad)
            val y0 = max(0, hyPx.toInt() - rad)
            val x1 = min(w, hxPx.toInt() + rad)
            val y1 = min(h, hyPx.toInt() + rad)
            val t = topColor(px, w, x0, y0, x1, y1, 1) { isBg(it, bgs, thr2) }
            if (t.count >= 10) ownColor = t.color
        }

        // Per-cell pixel statistics.
        val colOf = IntArray(w) { min((it / cell).toInt(), cols - 1) }
        val tot = IntArray(n)
        val fgCnt = IntArray(n)
        val ownCnt = IntArray(n)
        val oc = ownColor
        val own2 = cfg.ownColorThreshold * cfg.ownColorThreshold
        for (y in 0 until h) {
            val r = (y / cell).toInt()
            if (r >= rows) break
            val base = r * cols
            val row = y * w
            for (x in 0 until w) {
                val idx = base + colOf[x]
                tot[idx]++
                val c = px[row + x]
                if (isBg(c, bgs, thr2)) continue
                fgCnt[idx]++
                if (oc != null && dist2(c, oc) < own2) ownCnt[idx]++
            }
        }

        val isFg = BooleanArray(n)
        val isOwn = BooleanArray(n)
        var fgTotal = 0
        for (i in 0 until n) {
            if (ignored[i] || tot[i] == 0) continue
            if (fgCnt[i] >= cfg.fgCellFraction * tot[i]) {
                isFg[i] = true
                fgTotal++
                if (oc != null && ownCnt[i] * 2 >= fgCnt[i]) isOwn[i] = true
            }
        }

        val labels = IntArray(n)
        if (oc == null) {
            // Fallback: own snake = any connected blob touching the head area.
            val count = label(isFg, cols, rows, labels)
            val ownLabel = BooleanArray(max(count, 1))
            val rr = cfg.headSearchCells
            for (r in 0 until rows) for (c in 0 until cols) {
                val i = r * cols + c
                if (isFg[i] && hypot(c + 0.5f - headX, r + 0.5f - headY) <= rr) ownLabel[labels[i]] = true
            }
            for (i in 0 until n) if (isFg[i] && ownLabel[labels[i]]) isOwn[i] = true
        }

        val other = BooleanArray(n) { isFg[it] && !isOwn[it] }
        val count = label(other, cols, rows, labels)
        val core = IntArray(max(count, 1))
        for (r in 0 until rows) for (c in 0 until cols) {
            val i = r * cols + c
            val l = labels[i]
            if (l < 0) continue
            if (c > 0 && c < cols - 1 && r > 0 && r < rows - 1 &&
                labels[i - 1] == l && labels[i + 1] == l && labels[i - cols] == l && labels[i + cols] == l
            ) core[l]++
        }

        val kind = ByteArray(n)
        val foods = ArrayList<Food>()
        var ownCells = 0
        var hazardCells = 0
        for (r in 0 until rows) for (c in 0 until cols) {
            val i = r * cols + c
            when {
                ignored[i] -> kind[i] = CellKind.IGNORED
                isOwn[i] -> { kind[i] = CellKind.OWN; ownCells++ }
                other[i] -> {
                    if (core[labels[i]] >= cfg.minCoreCells) { kind[i] = CellKind.HAZARD; hazardCells++ }
                    else { kind[i] = CellKind.FOOD; foods.add(Food(c + 0.5f, r + 0.5f)) }
                }
            }
        }
        val nearest = foods.sortedBy { hypot(it.x - headX, it.y - headY) }.take(cfg.maxFoods)

        // Heading = from the centroid of nearby own-body cells towards the head.
        var sx = 0f; var sy = 0f; var sd = 0f; var cnt = 0
        for (r in 0 until rows) for (c in 0 until cols) {
            if (kind[r * cols + c] != CellKind.OWN) continue
            val dx = c + 0.5f - headX
            val dy = r + 0.5f - headY
            val d = hypot(dx, dy)
            if (d >= 2f && d <= cfg.bodyRadiusCells) { sx += dx; sy += dy; sd += d; cnt++ }
        }
        var heading: Float? = null
        var conf = 0f
        if (cnt >= cfg.bodyMinCells) {
            val mx = sx / cnt
            val my = sy / cnt
            val len = hypot(mx, my)
            if (len > 0.3f) {
                heading = atan2(-my, -mx)
                conf = min(1f, len / (0.6f * (sd / cnt)))
            }
        }

        return Analysis(
            frameW = w, frameH = h, cols = cols, rows = rows, cellSize = cell,
            kind = kind, foods = nearest, headX = headX, headY = headY,
            bodyHeading = heading, headingConfidence = conf, ownColor = ownColor,
            ownCells = ownCells, hazardCells = hazardCells,
            fgFraction = fgTotal.toFloat() / n, bgColors = bgs.size
        )
    }

    // ---------------------------------------------------------------- helpers

    private fun dist2(c: Int, d: Int): Int {
        val dr = ((c shr 16) and 255) - ((d shr 16) and 255)
        val dg = ((c shr 8) and 255) - ((d shr 8) and 255)
        val db = (c and 255) - (d and 255)
        return dr * dr + dg * dg + db * db
    }

    private fun isBg(c: Int, bgs: IntArray, thr2: Int): Boolean {
        for (b in bgs) if (dist2(c, b) < thr2) return true
        return false
    }

    private class Top(val color: Int, val count: Int)

    /** Most common 4-bit-quantised colour (returns its mean colour) among pixels not skipped. */
    private inline fun topColor(
        px: IntArray, w: Int, x0: Int, y0: Int, x1: Int, y1: Int, step: Int, skip: (Int) -> Boolean
    ): Top {
        val cnt = IntArray(4096)
        val rs = IntArray(4096)
        val gs = IntArray(4096)
        val bs = IntArray(4096)
        var y = y0
        while (y < y1) {
            val row = y * w
            var x = x0
            while (x < x1) {
                val c = px[row + x]
                if (!skip(c)) {
                    val r = (c shr 16) and 255
                    val g = (c shr 8) and 255
                    val b = c and 255
                    val k = ((r shr 4) shl 8) or ((g shr 4) shl 4) or (b shr 4)
                    cnt[k]++; rs[k] += r; gs[k] += g; bs[k] += b
                }
                x += step
            }
            y += step
        }
        var best = -1
        var bc = 0
        for (k in 0 until 4096) if (cnt[k] > bc) { bc = cnt[k]; best = k }
        if (best < 0) return Top(0, 0)
        return Top(((rs[best] / bc) shl 16) or ((gs[best] / bc) shl 8) or (bs[best] / bc), bc)
    }

    private fun estimateBackground(px: IntArray, w: Int, h: Int, thr2: Int): IntArray {
        val step = 3
        val samples = ((w + step - 1) / step) * ((h + step - 1) / step)
        val t1 = topColor(px, w, 0, 0, w, h, step) { false }
        if (t1.count == 0) return IntArray(0)
        val c1 = t1.color
        // A second background tone (checkerboard / pattern) is accepted only if it is common
        // AND spread over the whole frame -- walls or big snakes are concentrated, so they fail.
        val t2 = topColor(px, w, 0, 0, w, h, step) { dist2(it, c1) < thr2 }
        if (t2.count > samples * 0.15f && spread(px, w, h, t2.color, thr2) >= 14) {
            return intArrayOf(c1, t2.color)
        }
        return intArrayOf(c1)
    }

    private fun spread(px: IntArray, w: Int, h: Int, c: Int, thr2: Int): Int {
        val hits = IntArray(16)
        val tot = IntArray(16)
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val b = (y * 4 / h) * 4 + (x * 4 / w)
                tot[b]++
                if (dist2(px[y * w + x], c) < thr2) hits[b]++
                x += 3
            }
            y += 3
        }
        var n = 0
        for (i in 0 until 16) if (tot[i] > 0 && hits[i] >= tot[i] * 0.02f) n++
        return n
    }

    /** 8-connected component labelling. Returns the number of labels; unlabelled cells get -1. */
    private fun label(mask: BooleanArray, cols: Int, rows: Int, out: IntArray): Int {
        java.util.Arrays.fill(out, -1)
        val stack = IntArray(cols * rows)
        var next = 0
        for (s in 0 until cols * rows) {
            if (!mask[s] || out[s] != -1) continue
            var sp = 0
            stack[sp++] = s
            out[s] = next
            while (sp > 0) {
                val cur = stack[--sp]
                val cx = cur % cols
                val cy = cur / cols
                for (dy in -1..1) for (dx in -1..1) {
                    if (dx == 0 && dy == 0) continue
                    val nx = cx + dx
                    val ny = cy + dy
                    if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue
                    val ni = ny * cols + nx
                    if (mask[ni] && out[ni] == -1) { out[ni] = next; stack[sp++] = ni }
                }
            }
            next++
        }
        return next
    }
}
