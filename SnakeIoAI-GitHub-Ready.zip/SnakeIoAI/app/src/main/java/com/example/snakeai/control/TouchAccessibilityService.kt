package com.example.snakeai.control

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import com.example.snakeai.AppState
import com.example.snakeai.ai.Decision
import com.example.snakeai.ui.DebugOverlayView
import com.example.snakeai.util.ScreenUtil
import com.example.snakeai.vision.Analysis
import com.example.snakeai.vision.FracRect
import com.example.snakeai.vision.Zones

/**
 * Touch controller + safety overlays.
 *  - dispatches steering gestures (GestureController)
 *  - hosts the always-visible STOP button and optional debug minimap as TYPE_ACCESSIBILITY_OVERLAY
 *    windows (no SYSTEM_ALERT_WINDOW permission needed)
 *  - reports which package is in the foreground so gestures are only sent into the chosen game
 */
class TouchAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: TouchAccessibilityService? = null
    }

    lateinit var gestures: GestureController
        private set

    private val main = Handler(Looper.getMainLooper())
    private var stopView: Button? = null
    private var debugView: DebugOverlayView? = null
    @Volatile private var eventPkg: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        gestures = GestureController(this)
        instance = this
        AppState.notifyChanged()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = e.packageName?.toString()
            if (p != null && p != "com.android.systemui") eventPkg = p
        }
    }

    override fun onInterrupt() {
        AppState.emergencyStop()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        AppState.emergencyStop()
        hideOverlays()
        instance = null
        AppState.notifyChanged()
        return super.onUnbind(intent)
    }

    /** Package name of the active window (never reads text or content). */
    fun activePackage(): String? {
        val root = try { rootInActiveWindow } catch (e: Exception) { null }
        val p = root?.packageName?.toString()
        recycleQuietly(root)
        return p ?: eventPkg
    }

    @Suppress("DEPRECATION")
    private fun recycleQuietly(n: android.view.accessibility.AccessibilityNodeInfo?) {
        try { n?.recycle() } catch (_: Exception) {}
    }

    fun showOverlays(debug: Boolean, onStop: () -> Unit) {
        main.post {
            hideOverlaysNow()
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val (sw, sh) = ScreenUtil.realSize(this)

            fun params(r: FracRect, touchable: Boolean): WindowManager.LayoutParams {
                var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                val lp = WindowManager.LayoutParams(
                    (sw * (r.r - r.l)).toInt(), (sh * (r.b - r.t)).toInt(),
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT
                )
                lp.gravity = Gravity.TOP or Gravity.START
                lp.x = (sw * r.l).toInt()
                lp.y = (sh * r.t).toInt()
                return lp
            }

            val btn = Button(this).apply {
                text = "■ STOP AI"
                setTextColor(Color.WHITE)
                setBackgroundColor(0xF0C62828.toInt())
                textSize = 16f
                isAllCaps = false
                setOnClickListener { onStop() }
            }
            wm.addView(btn, params(Zones.STOP, true))
            stopView = btn

            if (debug) {
                val dv = DebugOverlayView(this)
                wm.addView(dv, params(Zones.MINIMAP, false))
                debugView = dv
            }
        }
    }

    fun updateDebug(a: Analysis?, d: Decision?) {
        debugView?.update(a, d)
    }

    fun hideOverlays() {
        main.post { hideOverlaysNow() }
    }

    private fun hideOverlaysNow() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        try { stopView?.let { wm.removeViewImmediate(it) } } catch (_: Exception) {}
        try { debugView?.let { wm.removeViewImmediate(it) } } catch (_: Exception) {}
        stopView = null
        debugView = null
    }
}
