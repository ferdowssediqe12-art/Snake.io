package com.example.snakeai

import java.util.concurrent.CopyOnWriteArrayList

/** Tiny shared state holder between service, accessibility service and UI (no extra libraries). */
object AppState {
    @Volatile var running = false
    @Volatile var status = "Idle"
    @Volatile var decisionLine = "-"
    @Volatile var debugLine = "-"
    @Volatile var stopHook: Runnable? = null

    private val listeners = CopyOnWriteArrayList<Runnable>()

    fun addListener(r: Runnable) { listeners.addIfAbsent(r) }
    fun removeListener(r: Runnable) { listeners.remove(r) }
    fun notifyChanged() { for (l in listeners) l.run() }

    /** Called by the STOP overlay button, the notification action and the STOP button in the UI. */
    fun emergencyStop() { stopHook?.run() }
}
