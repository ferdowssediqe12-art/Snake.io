package com.example.snakeai.ai

/**
 * Detects "nothing is happening": the picture stopped changing (paused / death screen /
 * full-screen ad / frozen game) or no own snake has been seen for a while.
 */
class StuckDetector(
    private val warnMs: Long,
    private val recoverMs: Long,
    private val giveUpMs: Long
) {
    enum class State { OK, WARN, RECOVER, GIVE_UP }

    private var sig: IntArray? = null
    private var lastChange = -1L
    private var lastSnake = -1L

    fun reset(now: Long) {
        sig = null; lastChange = now; lastSnake = now
    }

    fun onFrame(px: IntArray, w: Int, h: Int, now: Long) {
        if (lastChange < 0) reset(now)
        val g = 40
        val s = IntArray(g * g)
        for (j in 0 until g) for (i in 0 until g) {
            val y = (j * h / g + h / (2 * g)).coerceAtMost(h - 1)
            val x = (i * w / g + w / (2 * g)).coerceAtMost(w - 1)
            val c = px[y * w + x]
            s[j * g + i] = (((c shr 16) and 255) + ((c shr 8) and 255) + (c and 255)) / 3
        }
        val prev = sig
        if (prev != null) {
            var changed = 0
            for (k in s.indices) if (kotlin.math.abs(s[k] - prev[k]) > 12) changed++
            if (changed >= 3) lastChange = now
        }
        sig = s
    }

    fun noteSnake(found: Boolean, now: Long) {
        if (lastSnake < 0) lastSnake = now
        if (found) lastSnake = now
    }

    fun stuckMs(now: Long): Long {
        if (lastChange < 0) return 0
        return maxOf(now - lastChange, now - lastSnake)
    }

    fun state(now: Long): State {
        val t = stuckMs(now)
        return when {
            t >= giveUpMs -> State.GIVE_UP
            t >= recoverMs -> State.RECOVER
            t >= warnMs -> State.WARN
            else -> State.OK
        }
    }
}
