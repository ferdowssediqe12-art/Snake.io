package com.example.snakeai.ui

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.example.snakeai.AppSettings
import com.example.snakeai.AppState
import com.example.snakeai.control.TouchAccessibilityService
import com.example.snakeai.service.AiForegroundService

class MainActivity : Activity() {
    companion object {
        private const val REQ_CAPTURE = 1001
        private const val REQ_NOTIF = 1002
        private const val BG = 0xFF121417.toInt()
        private const val CARD = 0xFF1C2026.toInt()
        private const val TEXT = 0xFFE6E8EB.toInt()
        private const val MUTED = 0xFF9AA4B0.toInt()
        private const val GREEN = 0xFF2E7D32.toInt()
        private const val RED = 0xFFC62828.toInt()
        private const val BLUE = 0xFF1565C0.toInt()
    }

    private lateinit var tvStatus: TextView
    private lateinit var etPackage: EditText
    private val fields = LinkedHashMap<String, EditText>()
    private val refresher = Runnable { runOnUiThread { refresh() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun label(s: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun addButton(root: LinearLayout, title: String, color: Int, onClick: () -> Unit) {
        val b = Button(this)
        b.text = title
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(color)
        b.setOnClickListener { onClick() }
        root.addView(b, lp(10))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(28), dp(16), dp(28))
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        scroll.addView(root)
        setContentView(scroll)

        root.addView(label("Snake.io AI Assistant", 22f, TEXT, true))
        root.addView(
            label(
                "Experimental prototype. Vision is heuristic and can misjudge the scene. " +
                    "Logic is unit-tested on synthetic frames only; on-device behaviour needs your testing (see README).",
                12f, MUTED
            ), lp(4)
        )

        tvStatus = label("", 13f, TEXT)
        tvStatus.typeface = Typeface.MONOSPACE
        tvStatus.setBackgroundColor(CARD)
        tvStatus.setPadding(dp(12), dp(12), dp(12), dp(12))
        root.addView(tvStatus, lp(12))

        addButton(root, "1 · Open Accessibility settings", BLUE) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        root.addView(label("2 · Target app (package name)", 14f, TEXT, true), lp(16))
        etPackage = EditText(this)
        etPackage.hint = "e.g. the Snake.io package"
        etPackage.setText(AppSettings.targetPackage(this))
        etPackage.setTextColor(TEXT)
        etPackage.setHintTextColor(MUTED)
        etPackage.setSingleLine()
        root.addView(etPackage, lp())
        addButton(root, "Detect installed Snake.io", BLUE) { detectTarget() }

        addButton(root, "3 · START AI", GREEN) { onStartClicked() }
        addButton(root, "■ STOP AI", RED) { stopAi() }

        root.addView(label("Settings", 16f, TEXT, true), lp(20))
        for (d in AppSettings.defs) {
            root.addView(label(d.label, 12f, MUTED), lp(8))
            val et = EditText(this)
            et.setText(AppSettings.get(this, d.key))
            et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            et.setTextColor(TEXT)
            et.setSingleLine()
            fields[d.key] = et
            root.addView(et, lp())
        }
        addButton(root, "Save settings", BLUE) { saveSettings(); toast("Saved") }
        addButton(root, "Reset settings to defaults", 0xFF444B55.toInt()) {
            for (d in AppSettings.defs) { AppSettings.put(this, d.key, d.default); fields[d.key]?.setText(d.default) }
            toast("Defaults restored")
        }
    }

    override fun onStart() {
        super.onStart()
        AppState.addListener(refresher)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onStop() {
        AppState.removeListener(refresher)
        super.onStop()
    }

    private fun refresh() {
        val a11y = TouchAccessibilityService.instance != null
        val pkg = AppSettings.targetPackage(this).ifEmpty { "(not set)" }
        tvStatus.text = "Accessibility : ${if (a11y) "ON" else "OFF – enable it (step 1)"}\n" +
            "Screen capture: ${if (AppState.running) "ACTIVE" else "idle"}\n" +
            "Target app    : $pkg\n" +
            "Status        : ${AppState.status}\n" +
            "Decision      : ${AppState.decisionLine}\n" +
            "Debug         : ${AppState.debugLine}"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun saveSettings() {
        for ((k, v) in fields) AppSettings.put(this, k, v.text.toString().trim())
        AppSettings.setTargetPackage(this, etPackage.text.toString())
    }

    private fun detectTarget() {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = packageManager
        val hits = pm.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.second.contains("snake", ignoreCase = true) }
            .distinct()
        when {
            hits.isEmpty() -> toast("No installed app with 'snake' in its name. Type the package name manually.")
            hits.size == 1 -> { etPackage.setText(hits[0].first); toast("Found ${hits[0].second}") }
            else -> AlertDialog.Builder(this)
                .setTitle("Choose the game")
                .setItems(hits.map { "${it.second}\n${it.first}" }.toTypedArray()) { _, which ->
                    etPackage.setText(hits[which].first)
                }.show()
        }
    }

    private fun onStartClicked() {
        saveSettings()
        if (TouchAccessibilityService.instance == null) {
            toast("Enable the accessibility service first (step 1).")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        if (AppSettings.targetPackage(this).isEmpty()) {
            toast("Set the target app first (step 2).")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Please confirm")
            .setMessage(
                "If you continue:\n\n" +
                    "• Android will ask to record your screen. Only the screenshots are analysed on this phone; nothing is uploaded or saved.\n" +
                    "• The app will inject touch gestures, but only while the selected game is in the foreground.\n" +
                    "• A red STOP AI button stays on screen; the notification also has STOP.\n" +
                    "• It stops automatically after the configured time.\n\n" +
                    "Automating online games may violate their terms of service. Use at your own risk."
            )
            .setPositiveButton("I agree – continue") { _, _ -> askNotificationThenCapture() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askNotificationThenCapture() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        } else {
            requestCapture()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIF) requestCapture() // continue either way; STOP overlay works without it
    }

    @Suppress("DEPRECATION")
    private fun requestCapture() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        if (resultCode == RESULT_OK && data != null) {
            val i = Intent(this, AiForegroundService::class.java)
                .setAction(AiForegroundService.ACTION_START)
                .putExtra(AiForegroundService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(AiForegroundService.EXTRA_DATA, data)
            startForegroundService(i)
            packageManager.getLaunchIntentForPackage(AppSettings.targetPackage(this))?.let { startActivity(it) }
        } else {
            toast("Screen-capture permission was not granted.")
        }
    }

    private fun stopAi() {
        AppState.emergencyStop()
        stopService(Intent(this, AiForegroundService::class.java))
        refresh()
    }
}
