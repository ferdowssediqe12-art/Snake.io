package com.example.snakeai.capture

import android.media.Image

object FrameConverter {
    /** Copies an RGBA_8888 [Image] into [out] as 0xRRGGBB ints, honouring row/pixel stride. */
    fun toRgb(image: Image, out: IntArray) {
        val plane = image.planes[0]
        val buf = plane.buffer
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val w = image.width
        val h = image.height
        val row = ByteArray(rowStride)
        for (y in 0 until h) {
            buf.position(y * rowStride)
            val len = minOf(rowStride, buf.remaining())
            buf.get(row, 0, len)
            var o = y * w
            var i = 0
            for (x in 0 until w) {
                val r = row[i].toInt() and 0xFF
                val g = row[i + 1].toInt() and 0xFF
                val b = row[i + 2].toInt() and 0xFF
                out[o++] = (r shl 16) or (g shl 8) or b
                i += pixelStride
            }
        }
    }
}
