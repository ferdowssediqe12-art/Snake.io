package com.example.snakeai

import com.example.snakeai.ai.DecisionEngine
import com.example.snakeai.ai.Mode
import com.example.snakeai.ai.PIF
import com.example.snakeai.ai.StuckDetector
import com.example.snakeai.ai.angDiff
import com.example.snakeai.vision.FrameAnalyzer
import com.example.snakeai.vision.Zones
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.hypot

/** Synthetic-frame tests: they prove the logic, NOT that the real game looks like this. */
class VisionAndEngineTest {
    private val W = 360
    private val H = 780
    private fun rgb(r: Int, g: Int, b: Int) = (r shl 16) or (g shl 8) or b
    private val bg = rgb(20, 20, 40)
    private val green = rgb(0, 200, 0)
    private val yellow = rgb(255, 200, 0)
    private val red = rgb(210, 0, 0)

    private fun frame() = IntArray(W * H) { bg }

    private fun rect(px: IntArray, x0: Int, y0: Int, x1: Int, y1: Int, c: Int) {
        for (y in y0 until y1) for (x in x0 until x1) px[y * W + x] = c
    }

    private fun disc(px: IntArray, cx: Int, cy: Int, rad: Int, c: Int) {
        for (y in cy - rad..cy + rad) for (x in cx - rad..cx + rad)
            if (hypot((x - cx).toFloat(), (y - cy).toFloat()) <= rad) px[y * W + x] = c
    }

    /** Own snake: head at the screen centre (180,390), body trailing downwards => heading is UP. */
    private fun ownSnake(px: IntArray) {
        rect(px, 168, 390, 192, 520, green)
        disc(px, 180, 390, 14, green)
    }

    @Test fun detectsOwnSnakeFoodHazardAndHeading() {
        val px = frame()
        ownSnake(px)
        disc(px, 230, 300, 5, yellow)
        rect(px, 100, 250, 300, 280, red)
        val a = FrameAnalyzer().analyze(px, W, H)
        assertTrue("snake found", a.hasSnake)
        assertTrue("hazard found", a.hazardCells > 0)
        val fx = 230f / a.cellSize
        val fy = 300f / a.cellSize
        assertTrue("food near expected cell", a.foods.any { hypot(it.x - fx, it.y - fy) < 2f })
        val hd = a.bodyHeading
        assertNotNull(hd)
        assertTrue("heading is up", abs(angDiff(hd!!, -PIF / 2)) < 0.5f)
    }

    @Test fun steersTowardsReachableFood() {
        val px = frame()
        ownSnake(px)
        disc(px, 230, 300, 5, yellow)
        val a = FrameAnalyzer().analyze(px, W, H)
        val d = DecisionEngine().decide(a)
        val foodAngle = kotlin.math.atan2(300f - 390f, 230f - 180f)
        assertTrue("angle near food direction", abs(angDiff(d.angle, foodAngle)) < 0.45f)
        assertTrue(d.steer)
    }

    @Test fun avoidsWallAhead() {
        val px = frame()
        ownSnake(px)
        rect(px, 0, 330, 360, 350, red) // full-width wall 5-8 cells ahead
        val a = FrameAnalyzer().analyze(px, W, H)
        val d = DecisionEngine().decide(a)
        assertTrue("does not head straight into the wall", abs(angDiff(d.angle, -PIF / 2)) > 0.5f)
    }

    @Test fun ignoresOwnOverlayZone() {
        val px = frame()
        ownSnake(px)
        // paint a fake "STOP button" in its zone: must not become a hazard
        val z = Zones.STOP
        rect(px, (z.l * W).toInt(), (z.t * H).toInt(), (z.r * W).toInt(), (z.b * H).toInt(), red)
        val a = FrameAnalyzer().analyze(px, W, H, listOf(z))
        assertEquals(0, a.hazardCells)
    }

    @Test fun noSnakeMeansNoSteering() {
        val a = FrameAnalyzer().analyze(frame(), W, H)
        assertTrue(!a.hasSnake)
        assertEquals(Mode.NO_SNAKE, DecisionEngine().decide(a).mode)
    }

    @Test fun stuckDetectorEscalates() {
        val s = StuckDetector(3000, 8000, 60000)
        val px = frame()
        s.reset(0)
        var t = 0L
        while (t <= 9000) { s.onFrame(px, W, H, t); s.noteSnake(true, t); t += 500 }
        assertEquals(StuckDetector.State.RECOVER, s.state(9000))
        // a changing frame resets the timer
        rect(px, 0, 0, 360, 400, red)
        s.onFrame(px, W, H, 9500)
        assertEquals(StuckDetector.State.OK, s.state(9600))
    }
}
