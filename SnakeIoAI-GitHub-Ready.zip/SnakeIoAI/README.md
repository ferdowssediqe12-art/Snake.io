# Snake.io AI (prototype)

An on-device assistant that watches the screen while the **installed Snake.io Android app** is in
the foreground, estimates where your snake, food and hazards are, and steers by injecting swipe
gestures. Everything runs locally; no accounts, no network, no paid services, no ML model files.

> **Status: untested prototype.** This project was written without access to an Android SDK or a
> device, so it has **not been compiled or run on a phone yet**. See "Tested vs. untested".
> Online-game automation may violate the game's terms of service and can get accounts banned. Use at your own risk.

## Versions

| Item | Version |
|---|---|
| Android Studio | Koala (2024.1.1) or newer |
| JDK | 17 (Android Studio's bundled JBR is fine) |
| Gradle | 8.7 (via `gradle/wrapper/gradle-wrapper.properties`) |
| Android Gradle Plugin | 8.5.2 |
| Kotlin | 1.9.24 |
| compileSdk / targetSdk / minSdk | 34 / 34 / 26 (Android 8.0+) |
| Runtime dependencies | none (platform APIs only). Tests: JUnit 4.13.2 |

`gradle-wrapper.jar` and the `gradlew` scripts are binaries/scripts that could not be generated here.
Android Studio does not need them (it syncs with the wrapper properties). For command-line builds run
`gradle wrapper --gradle-version 8.7` once, using any installed Gradle.

## Architecture

```
MainActivity (UI, consent, settings)
   |  starts, after MediaProjection consent
   v
AiForegroundService  (type mediaProjection, HandlerThread)
   |-- capture loop  every captureIntervalMs:
   |       VirtualDisplay -> ImageReader (downscaled) -> FrameConverter -> FrameAnalyzer -> Analysis
   |       -> StuckDetector (static picture / no snake)
   '-- decision loop every decisionIntervalMs:
           foreground-package check -> DecisionEngine -> GestureController
                                                            |
TouchAccessibilityService  <-----------------------------'
   dispatchGesture(), STOP overlay button, optional debug minimap, active-package check
```

* **Vision (`vision/FrameAnalyzer`)**: colour-agnostic. Finds 1-2 dominant background colours, marks
  non-background pixels per grid cell, takes the colour found around the head position (screen
  centre by default, because the camera follows your head) as "own snake", classifies the rest into
  hazards (thick blobs = other snakes) and food (thin/small blobs), and estimates heading from where
  your body trails behind the head.
* **Decision (`ai/DecisionEngine`)**: casts 36 rays from the head, scores each direction by free
  distance, hazard proximity, food attraction and turn cost, smooths the result, detects circling and
  breaks out of it. In danger it skips smoothing.
* **Control (`control/`)**: each decision is a short swipe from the head position toward
  `head + direction * radius`. Optional experimental HOLD mode keeps one finger down and steers it.
* **Safety**: gestures are sent only while the chosen game is the active window; red STOP overlay,
  notification STOP, STOP in the app; auto-stop after N minutes, when the game leaves the foreground,
  or when the picture is static / no snake is found for a long time.

## Build and install

1. Install Android Studio (Koala or newer). On your phone: Settings > About phone > tap *Build number* 7 times, then
   Settings > System > Developer options > enable **USB debugging**.
2. Android Studio: **File > Open** and select the `SnakeIoAI` folder (the one containing `settings.gradle.kts`).
3. Let Gradle sync (needs internet once to download Gradle 8.7, AGP and the Android SDK 34 platform;
   accept SDK licences if prompted). If asked about JDK, choose 17.
4. Build the debug APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Output:
   `app/build/outputs/apk/debug/app-debug.apk`.
5. Install: connect the phone by USB, accept the debugging prompt, pick the phone in the device selector and press **Run**
   (or `adb install -r app/build/outputs/apk/debug/app-debug.apk`).
6. Optional: run the JVM tests with **Run > Run 'All Tests'** on `app/src/test`
   (or `./gradlew :app:testDebugUnitTest` after creating the wrapper).

## First run

1. Open **Snake.io AI**. Tap **1 · Open Accessibility settings** and enable **Snake.io AI touch controller**.
   * On Android 13+ for sideloaded apps the switch may be greyed out: open Settings > Apps > Snake.io AI >
     (⋮ menu) > **Allow restricted settings**, then try again.
   * Android shows a warning dialog; this service injects touches and reads only the foreground app's package name.
2. Tap **Detect installed Snake.io** (or type the package name). Tap **Save settings** if you changed values.
3. Tap **3 · START AI**, read and accept the consent dialog, allow notifications, then accept Android's
   screen-capture dialog (on Android 14+ choose **Entire screen**).
4. The game opens. Start a round yourself (the AI does not press Play). A red **STOP AI** bar appears at the top;
   tap it any time. If you do not see the AI steering, see Troubleshooting.

## Settings (all in the app)

Capture/decision intervals, capture downscale, grid columns, background tolerance, occupied-cell fraction,
head position, smoothing, steering radius/duration, HOLD mode, decision weights, look-ahead and danger
distances, stuck timeouts, optional recovery tap, max run time, leave-game timeout, debug minimap.
Defaults are guesses; **expect to tune `bgThreshold`, `fgCellFraction`, head position and steering radius per device.**

Debug minimap: draws what the vision sees (red = hazard, green = own, yellow = food, white circle = head,
cyan line = estimated heading, white line = chosen direction) in the bottom-left corner. That corner is
excluded from analysis, so it blinds the AI there. Use it only while tuning.

## Detection limitations (please read)

* The AI does **not** reliably identify every object. It is a colour/shape heuristic, not a trained detector.
* It assumes a mostly uniform or evenly patterned background, the camera centred on your head, portrait orientation,
  and that your snake's dominant colour differs from the background.
* Other snakes with a similar colour to yours, glowing/animated skins, power-ups, borders, HUD elements, ads or
  popups can be misclassified. Food clusters from dead snakes may be treated as hazards or food inconsistently.
* Own-snake heading comes from the visible body; a tightly coiled body gives low confidence and the last command is used.
* Other snakes are treated as static in each frame (no motion prediction).
* The game's real control scheme is unverified. The code assumes dragging from the head position toward a direction
  steers the snake and that the snake keeps going when the finger lifts. If not, try HOLD mode or adjust radius/duration.
* Death/menu/ad screens are only detected indirectly (no snake near the head, or static picture). The app then stops steering
  and eventually stops itself. A recovery tap is off by default because it can hit ads.
* The accessibility overlay (STOP bar) is visible in captured frames; its zone is masked in analysis.

## Tested vs. untested

| Area | Status |
|---|---|
| Vision, decision engine, stuck detector logic | Written with JVM unit tests on synthetic frames (`VisionAndEngineTest`). **Not executed here** (no Kotlin compiler/SDK in the authoring environment): run them yourself. |
| Gradle/Manifest/Kotlin compilation | **Not compiled.** Expect possible small compile errors to fix on first sync. |
| MediaProjection capture, foreground service (incl. Android 14 rules) | **Needs device testing** |
| Accessibility gestures, overlay STOP button, foreground-package check | **Needs device testing** |
| Real Snake.io colours, control scheme, performance (fps) | **Unknown: needs device testing and tuning** |
| HOLD mode | Experimental |

## Test plan

1. **Unit tests** pass (`VisionAndEngineTest`).
2. **Install and permissions**: accessibility ON shows in the app status; consent dialog appears; Android capture dialog appears; notification shows with STOP.
3. **Safety first**: press START with Snake.io *not* started: status says paused/waiting and nothing is touched. Press the red STOP bar, the notification STOP and the in-app STOP; each must end capture and remove overlay.
4. **Capture**: enable *Debug minimap*, start a round, confirm the minimap shows your snake in green near the white head circle. If not, fix head X/Y and `bgThreshold`.
5. **Classification**: watch hazards (red) on other snakes and food (yellow) on pellets. Tune `bgThreshold` (higher if background shows as hazards/food, lower if snakes vanish) and `fgCellFraction`.
6. **Steering**: with the minimap on, confirm the white decision line points to food/away from hazards and the real snake follows. If steering is ignored, adjust `swipeRadiusPx`/`swipeDurationMs` or try HOLD mode.
7. **Recovery**: let the snake die; confirm status shows no snake/stall and the AI stops itself after the give-up time. Switch to another app; confirm gestures stop immediately.
8. **Endurance**: 10-15 minute run: check fps in the debug line (target 5+), no overheating, max-run auto-stop works.

## Troubleshooting

| Symptom | Fix |
|---|---|
| Accessibility switch greyed out | App info > ⋮ > *Allow restricted settings* (Android 13+). |
| Start says accessibility not enabled | Re-enable the service; some phones kill it when battery-optimised: exempt the app from battery optimisation. |
| Capture dialog appears but nothing happens | Check notification permission; on Android 14+ choose *Entire screen*; read the Status line for an error message. |
| "Paused – foreground is X" | The target package is wrong. Use *Detect installed Snake.io* or enter the exact package. |
| "No snake found at head position" | Head X/Y wrong (try 0.5 / 0.5, or 0.5 / 0.55), `bgThreshold` too high, or you are in a menu / dead / ad. |
| Everything is red (hazard) | `bgThreshold` too low for a textured background; raise it (45-70). |
| Snake not steering | Game may ignore injected gestures or use a different control scheme; try HOLD mode, larger radius, longer gesture. |
| Overlay missing | Overlay is added by the accessibility service: disable/enable the service and restart the AI. |
| Stops by itself | Check the Status line: max run time, game left foreground, static picture, or capture stopped by Android. |
| Display size changed | Rotation changed; keep portrait and restart. |
| Low fps | Increase capture downscale (4-5), reduce grid columns (32-40), raise intervals. |

## Licensing and model files

No machine-learning model, OpenCV or third-party library is used or required, so there is nothing to download.
JUnit 4.13.2 (test scope only) is licensed under EPL-2.0. Add a licence for your own code as you see fit.
Snake.io is a trademark/property of its publisher; this project is unaffiliated and does not touch game files, memory, or network traffic.

## Possible next steps (not implemented)

Motion prediction of enemy snakes, template matching with your own labelled screenshots, a small on-device model trained on
your own recordings (e.g., TensorFlow Lite, Apache-2.0), automatic Play-button handling.

## Build APK with GitHub Actions (phone-friendly)

A workflow is included at `.github/workflows/android-apk.yml`. Upload the **contents** of this project to the root of a GitHub repository (GitHub does not automatically extract an uploaded ZIP), then open **Actions → Build Android APK → Run workflow** if it did not run automatically. On success, download the `SnakeIoAI-debug-apk` artifact and extract `app-debug.apk` from it. See `README-GITHUB-MOBILE-FA.txt` for mobile-specific instructions.

The project remains an untested prototype until installed and tested on a real device. A successful build does not prove the screen analysis or gesture control works correctly.
