// Root build file. Versions are pinned to a known-compatible set:
// Gradle 8.7, Android Gradle Plugin 8.5.2, Kotlin 1.9.24, JDK 17.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
